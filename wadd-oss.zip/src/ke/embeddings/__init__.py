"""Embeddings package."""
